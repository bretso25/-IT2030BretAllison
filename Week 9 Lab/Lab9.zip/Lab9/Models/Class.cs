﻿using System.ComponentModel.DataAnnotations;
namespace FutureValue.Models
{
    public class FutureValueModel
    {
        [Required(ErrorMessage =
        "Please enter a Sub Total.")]
        public decimal? SaleAmount { get; set; }
        [Required(ErrorMessage =
        "Please enter a Tax Percent")]
        [Range(0.1, 10.0, ErrorMessage =
        "Tax rate must be between 0.1 and 10.0.")]
        public decimal? TaxPercent { get; set; }

        public decimal? CalculateFutureValue()
        {
            decimal? InterestRate = (TaxPercent) / 100;
            decimal? futureValue = 0;
            decimal? totalamt = 0;

            futureValue = (SaleAmount * InterestRate);
            totalamt = SaleAmount + futureValue;

            return futureValue;
        }
        public decimal? CalculateTotal()
        {
            decimal? InterestRate = (TaxPercent) / 100;
            decimal? futureValue = 0;
            decimal? totalamt = 0;

            futureValue = (SaleAmount * InterestRate);
            totalamt = SaleAmount + futureValue;

            return totalamt;
        }
    }
}
