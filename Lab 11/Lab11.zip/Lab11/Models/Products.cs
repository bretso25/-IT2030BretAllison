﻿using System.ComponentModel.DataAnnotations;
using System.Security.Cryptography;

namespace Lab5.Models
{
    public class Products
    {
        //EE core will configure the database to generate this value
        [Key]

        public int ProductId { get; set; }

        [Required(ErrorMessage = "Please enter a name for the service")]

        public string? Name { get; set; }

        [Required(ErrorMessage = "Please enter a category for the service.")]

        public string? Category { get; set; }

        [Required(ErrorMessage = "Please enter a size for the service")]
        [Range(0, 26, ErrorMessage = "Sizes are between 0 and 26.")]

        public int? Size { get; set; }

        [Required(ErrorMessage = "Please enter a price for the product")]

        public decimal? Price { get; set; }
    }
}
