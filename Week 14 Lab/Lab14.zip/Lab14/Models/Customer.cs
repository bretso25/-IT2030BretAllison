﻿using System.ComponentModel.DataAnnotations;

namespace Lab9.Models
{
    public class Customer
    {
        [Required(ErrorMessage = "Please enter a first name")]
        [StringLength(10, ErrorMessage = "First Name must be 10 characters or less.")]
        [RegularExpression("^[a-zA-z]+$", ErrorMessage = "First Name may not contain numbers or special characters.")]
        public string? FirstName { get; set; }

        [Required(ErrorMessage = "Please enter a last name")]
        [StringLength(10, ErrorMessage = "Last Name must be 10 characters or less.")]
        [RegularExpression("^[a-zA-z]+$", ErrorMessage = "Last Name may not contain numbers or special characters.")]
        public string? LastName { get; set; }

        [Required(ErrorMessage = "Please enter a city")]
        public string? City { get; set; }

        [Required(ErrorMessage = "Please enter a Street Address")]
        public string? StreetAddress { get; set; }

        [Required(ErrorMessage = "Please enter state")]
        [StringLength(2, ErrorMessage = "State must be 2 characters or less.")]
        [RegularExpression("^[a-zA-z]+$",
        ErrorMessage = "State may not contain numbers or speical characters")]
        public string? State { get; set; }

        [Required(ErrorMessage = "Please enter a zip code")]
        [StringLength(5, ErrorMessage = "Zip code must be 5 digits.")]
        [RegularExpression("[0-9]{5}",
        ErrorMessage = "Zip code may not contain letters or speical characters and must be 5 digits.")]
        public string? Zip { get; set; }

        [Required(ErrorMessage = "Please enter a phone number")]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", 
        ErrorMessage = "Not a valid phone number. 999-999-9999")]

        public string? Phone { get; set; }

        [Required(ErrorMessage = "Please enter an email address")]
        public string? Email { get; set; }
    }
}
