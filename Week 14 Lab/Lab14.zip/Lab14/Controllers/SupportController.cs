﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lab9.Controllers
{
    public class SupportController : Controller
    {
        [HttpGet]
        public IActionResult Support()
        {
            return View();
        }

        [HttpPost]

        public IActionResult Support(Lab9.Models.Customer customer)
        {
            var Customer = new Lab9.Models.Customer();
            return View(customer);
        }
    }
}
