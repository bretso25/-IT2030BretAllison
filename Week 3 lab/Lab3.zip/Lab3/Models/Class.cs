﻿using System.ComponentModel.DataAnnotations;
namespace FutureValue.Models
{
    public class FutureValueModel
    {
        [Required(ErrorMessage =
        "Please enter a sub total.")]
        [Range(1, 100, ErrorMessage =
        "Subtoal must be above 0")]
        public decimal? Subtotal { get; set; }
        [Required(ErrorMessage =
        "Please enter a tax percent")]
        [Range(0.1, 10.0, ErrorMessage =
        "Tax rate must be between 0.1 and 10.0.")]
        public decimal? TaxPercent { get; set; }
        //[Required(ErrorMessage = "Please enter a number of years.")]
        //[Range(1, 50, ErrorMessage =
//"Number of years must be between 1 and 50.")]
        //public int? Years { get; set; }
        public decimal? CalculateFutureValue()
        {
            //int? months = 0;
            decimal? InterestRate = TaxPercent / 100;
            decimal? futureValue = 0;
            decimal totalamt = 0;

            //for (int i = 0; i < months; i++)
            //{
            //futureValue = (futureValue + Subtotal) *
            //(1 + monthlyInterestRate);
            // }
            futureValue = Subtotal - InterestRate;
            
            return futureValue;
        }
    }
}
